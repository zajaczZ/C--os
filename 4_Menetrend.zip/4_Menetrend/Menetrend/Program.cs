﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Menetrend
{
    class Train
    {
        public int vonatid;
        public int allomasid;
        public DateTime ido;
        public string megy;
       

        public Train(string sor)
        {
            string[] temp = sor.Split('\t');
            vonatid= Convert.ToInt32(temp[0]);
            allomasid= Convert.ToInt32(temp[1]);
            ido = Convert.ToDateTime(temp[2]+" : "+temp[3]);
            megy = temp[4];
            

        }
    }
   
    internal class Program
    {
        static List<Train> lista = new List<Train>();
        static void beolvas()
        {
            
            StreamReader sr = new StreamReader("vonat.txt");
            while (!sr.EndOfStream)
            {
                Train uj = new Train (sr.ReadLine());
                lista.Add(uj);
                

            }
            sr.Close();
        }
        static void  kiir()
        {
            foreach (var item in lista)
            {
                Console.WriteLine(item.ido.ToShortTimeString());
            }

        }
        static void f2()
        {
            Console.WriteLine($"Az állomások száma: { lista.GroupBy(x => x.allomasid).Count()}\na vonatok száma: {lista.GroupBy(x => x.vonatid).Count()}");
        }
        static void f3()
        {
            int fasz = 0;
            
            List<int>legnagyobb= new List<int>();
            for (int i = 1; i < lista.Count(); i++)
            {
                if (lista[i].megy != lista[i-1].megy)
                {

                    Console.WriteLine(((((lista[i].ido.Hour) + (lista[i].ido.Minute)) - ((lista[i - 1].ido.Hour ) + (lista[i - 1].ido.Minute)))));

                }
               
                

            }
          ;
           
        }
        static void f4()
        {
            Console.WriteLine("Adja meg a vonat azonosítóját:");
            int thomas = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Óra és perc");
            DateTime áör = Convert.ToDateTime(Console.ReadLine());
            DateTime ertek = new DateTime(2022, 03, 01, 22, 22, 30);

            if (áör.Minute < ertek.Minute && áör.Hour == ertek.Hour)
            {
                Console.WriteLine($"A {thomas} vonat útjának a hossza rövidebb volt {(ertek.Minute) - (áör.Minute)} perccel");
            }
            if (áör.Minute > ertek.Minute && áör.Hour == ertek.Hour)
            {
                Console.WriteLine($"A {thomas} vonat útjának hossza hoszsabb volt a vártnál {(áör.Minute) - (ertek.Minute)} perccel");

            }
            if (áör.Hour > ertek.Hour)
            {
                Console.WriteLine($"A {thomas} vonat útjának hossza hoszsabb volt a vártnál {((áör.Minute) - (ertek.Minute)) + (áör.Hour * 60) - (ertek.Hour * 60)} perccel");
            }
            if (áör.Hour < ertek.Hour)
            {
                Console.WriteLine($"A {thomas} vonat útjának hossza rövidebb volt a vártnál {((ertek.Minute) - (áör.Minute)) + (ertek.Hour * 60) - (áör.Hour * 60)} perccel");
            }
            if (áör.Hour == ertek.Hour && ertek.Minute == áör.Minute)
            {
                Console.WriteLine($"A {thomas} vonat pontosan érkezett");
            }

            StreamWriter sr = new StreamWriter($"{thomas}.txt");
            foreach (var item in lista)
            {
                if (item.vonatid==thomas && item.megy=="E")
                {

                    sr.Write($"{item.allomasid} állomás: {item.ido.Hour}:{item.ido.Minute}\n ");
                }
                
            }
            sr.Close();
            

            

        }
        static void f7()
        {


        }
        static void Main(string[] args)
        {
            beolvas();
            //kiir();
            f2();
            //f3();
            f4();
            f7();
           


            Console.ReadKey();

        }
    }
}
